BobLightd Server for control of Philips Hue Lights
==================================================

This project is designed to provide an optimised boblightd Server
for controlling Philips Hue lights only.
It's intention is to be used in conjuction with the MrMC application
available for the AppleTV4 when using the LightEffects add-on

----

This is the README file for the project.


